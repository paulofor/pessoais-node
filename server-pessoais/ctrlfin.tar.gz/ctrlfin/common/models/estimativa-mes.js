'use strict';

module.exports = function(Estimativames) {

};
